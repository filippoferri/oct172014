<div class="no-found tk-nimbus-sans-condensed">
  <span class="huge">404</span>
  <p class="text-center"><?php _e('Oops, something went wrong!', 'roots'); ?></p>
</div>



