<div class="page-header">
<!-- <img class="bg-header" src="http://lorempixel.com/1059/330/transport" alt="">-->
  <?php putRevSlider( "page" ) ?>
  <div class="container">
<!--
    <h1>
      <?php echo roots_title(); ?>
    </h1>
-->
  </div>
</div>
